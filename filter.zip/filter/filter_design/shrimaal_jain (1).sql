-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 30, 2019 at 05:42 AM
-- Server version: 5.6.45
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shrimaal_jain`
--

-- --------------------------------------------------------

--
-- Table structure for table `bm_admin_users`
--

CREATE TABLE `bm_admin_users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bm_admin_users`
--

INSERT INTO `bm_admin_users` (`user_id`, `username`, `email`, `password`) VALUES
(3, '101', 'aj180689@gmail.com', '6bc6360970f9fdc3226a3da3c25e1ead');

-- --------------------------------------------------------

--
-- Table structure for table `head_of_family`
--

CREATE TABLE `head_of_family` (
  `hof_id` int(11) NOT NULL,
  `hof_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hof_Job` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hof_native_place` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hof_mob_num` bigint(20) NOT NULL,
  `hof_dob` date NOT NULL,
  `hof_email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hof_password` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hof_add` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hof_img` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `head_of_family`
--

INSERT INTO `head_of_family` (`hof_id`, `hof_name`, `hof_Job`, `hof_native_place`, `hof_mob_num`, `hof_dob`, `hof_email`, `hof_password`, `hof_add`, `hof_img`) VALUES
(44, 'Surendra Kumar Jain', 'Private Secretary', 'Lalsot', 9414050220, '1964-10-26', 'skjain_41@yahoo.com', 'ayush7891', '31, Prem Nagar, Gurjar Ki Thadi, Jaipur. 302019', 'WhatsApp Image 2018-09-29 at 3.01.25 PM.jpeg'),
(47, 'Rakesh Kumar Jain ', '', 'Bharatpur', 9413341206, '0000-00-00', 'rkjain343@gmail.com', '', '80/30, Patel Marg, &nbsp;Nyay Path, Mansarovar, Jaipur-302020', 'IMG-20170424-WA0005.jpg'),
(48, 'K C Jain', '', 'Chirawanda ', 9414200141, '0000-00-00', 'kcjain86 @yahoo.com', '123456', '62/75 pratap nagar&nbsp;<div>Sanganer</div><div>Jaipur</div>', '20170910_202205.jpg'),
(49, 'Anil Jain', '', 'Liwali', 9414963128, '0000-00-00', 'aniljain1305@gmail.com ', '', '<br>', '_20170910_220404.jpg'),
(50, 'Dr Indra Kumar Jain', '', 'Sesa', 8560000120, '0000-00-00', 'ikjainshrimal@gmail.com', '', '2 Sarvodaya Colony Lavkush Nagar Tonk Phatak Jaipur 302015', 'IMG_20170520_092536.jpg'),
(53, 'NEHRU LAL JAIN', 'business', 'Neenrada Sawaimadhop', 9982797140, '1970-01-07', 'jainnehru5@gmail.com', '123456', 'P.no.36 Khandelwal colony Goner Road<div>Luniyawas</div><div>Jaipur</div>', 'DSC_1655.JPG'),
(54, 'BUDDHI PRAKASH JAIN', '', 'Neenrada Sawaimadhop', 9468666601, '1979-07-05', 'bpjain5779@yahoo.com', '', 'P.no.36 Khandelwal colony Goner Road<div>Luniyawas</div><div>Jaipur</div>', 'DSC_1656.JPG'),
(55, 'ASHOK JAIN', '', 'Dabar', 9314323666, '1964-01-30', 'jainmobilenmore@gmail.com', '', '61/16 rajat path, mansarovar jaipur 302020', 'IMG20170402071543.jpg'),
(56, 'PRAMOD KUMAR JAIN', '', 'MALARNA DOONGER', 8824866700, '1968-12-12', 'suchitrajain03@gmail.com', '', '13/72 &nbsp;SWARAN PATH MANSAROVER JAIPUR 302020', '123456.jpg'),
(57, 'ARVIND KUMAR JAIN', '', 'BHAWAR', 9414518452, '1967-10-15', 'arvindjain2000@yahoo.co.in', '', '288, GOVIND NAGAR &nbsp; &nbsp; ( east), AMER ROAD, JAIPUR-302002', 'photo.jpg'),
(58, 'MUKESH KUMAR JAIN', '', 'MALARNA DOONGER', 9829318896, '0000-00-00', 'NO', '', '18 MAHARNA PRATAP CPLONY SAWAI MADHOPUR', 'IMG-20170828-WA0003 (1).jpg'),
(63, 'Prashant Jain', '', 'Vajirpur', 9314642868, '1978-05-05', 'jainprashant55@gmail.com', '', '405,Fourth Floor ,<div>Dhan Shri First,&nbsp;</div><div>Central Spine,&nbsp;</div><div>Vidhyadhar&nbsp;Nagar, Jaipur</div>', 'â€ª+91 93146 42868â€¬ 20170912_155126.jpg'),
(64, 'VIRENDRA KUMAR JAIN', '', 'MALARNA DUNGAR', 9460762426, '1940-10-15', 'jainkumar1609@gmail.com', '', '650,SURYA NAGAR GOPALPURA BYE-PASS RIDHHI SIDHHI CHOURAHA JAIPUR', 'DSC_0147.JPG'),
(65, 'JITENDRA KUMAR JAIN', '', 'Village -Kadi jhonpr', 9602523708, '1983-11-11', 'jainjk83@yahoo.in', 'jain8353', 'P.50 Taranagar-A Khatipura road Jhotwara Jaipur (Raj.)<div>302012</div>', '20170813_182946.jpg'),
(66, 'PURAN MAL JAIN', '', 'Neenrada Sawaimadhop', 9829236949, '1983-07-01', 'pmj_1983@gmail.com', '', 'P.no.36 Khandelwal colony Goner Road<div>Luniyawas</div><div>Jaipur</div>', 'IMG-20170912-WA0036.jpg'),
(68, 'Late', 'Late. Sh. Vimal chand jain', 'Dabar', 9929010586, '1948-12-19', 'jainmobilenmore@gmail.com', '', '10, lov_kush Ngr 1st<div>Tonk phatak,Tonk phatak jaipur 302015</div>', 'IMG-20170619-WA0020.jpg'),
(72, 'Veerendra jain', 'Shopkeeper ', 'Futera kalan', 8519007476, '1967-07-27', 'jshishanshu@gmail.com', '', '<br>', 'IMG-20170929-WA0001.jpg'),
(78, 'Mr.N.K.Jain', 'Pvt Service', 'Dabur', 9950053334, '1956-01-01', 'Arunjap@gmail.com', '', '<br>', '1506769709169-50784346.jpg'),
(81, 'Narendra Kumar Jain', 'Confectioner ', 'Malarna Doonger, Dis', 9828449834, '1962-06-02', 'virendrajain10@gmail.com', '', '63/138, Sector - 6, Pratap Nagar, Sanganer, Jaipur -302033', 'PAPA.jpg'),
(82, 'Ashok Kumar Jain', 'Marketing manager ATC Sawai Madhopur', 'Sawai Madhopur', 9414031542, '1962-02-14', 'mohitjain11799@gmail.com', '', 'OPP. New Grain Mandi Tehriya Bhavan k samne Mahaveer Nagar, Sawai MADHOPUR (RAJASTHAN)', '22140552_1839880199656480_395571449_o.jpg'),
(87, 'à¤°à¤¾à¤•à¥‡à¤¶ à¤œà¥ˆà¤¨', 'Teacher', 'Sawaimadhopur', 9414225119, '1977-07-01', '3278rakeshjain@gmail.com', '', 'P. N. 3 mahaveer nager palampur swm', 'IMG_20170929_062842.jpg'),
(88, 'Dharmendra jain', 'Business', 'Jaipur', 9351360939, '0000-00-00', 'Jain.dharmendrakumar@yahoo.com', '', '21 A Nand vihar colony Malpura gate&nbsp;<div>Sanganer</div><div>Jaipur</div>', 'FB_IMG_1514785324771-1.jpg'),
(89, 'Ashok Jain', 'Accountant', 'Indore', 9993071002, '1960-09-11', 'suniljain2121@yahoo.com ', '', 'Flat No 203 Nakoda Tower<div>24-25 Sir Hukumchand Marg&nbsp;</div><div>Above SBI Bank Indore 452002</div>', 'IMG_20171209_142645.jpg'),
(91, 'SATISH CHANDRA JAIN', 'GOVERNT SERVICE - DIVISIONAL COMMISSIONER OFFICE, JAIPUR', 'KISHOREPURA', 9414361178, '1964-06-15', 'satishjain64@gmail.com', '', 'NEAR WATER TANK, SOMNATH NAGAR,<div>DAUSA</div>', 'IMG-20140126-WA0015.jpg'),
(92, 'BUDHI PRAKASH JAIN ', 'Kanojia Parivar', 'Village - Garhkhera,', 9772834000, '1984-07-10', 'bpjains@gmail.com', '', 'Dear Team,&nbsp;<div>Shrimal Jain Samaj,&nbsp;</div><div>I want to add my family list in the shrimal jain samaj.&nbsp;</div><div><br></div><div>Thanking You</div>', 'IMG_20180517_131136.jpg'),
(93, 'BUDHI PRAKASH JAIN ', '', 'GARHKHERA ', 9772834000, '1984-07-10', 'Bpjains@gmail.com ', '', 'F-1, Plot No-792, Gali No-8, DEVI NAGAR,&nbsp;<div>Sodala, Jaipur&nbsp;</div><div>Rajasthan&nbsp;<br><div><br></div></div>', 'IMG-20161222-WA0003.jpg'),
(94, 'Vimal jain', 'Vimal jain', 'Malarna dungar', 9602832321, '1966-07-01', 'vimalj66@gmail.com', '', '1E,RAM VIHAR CPLONY, NEAR IIHMR, SANGANER, JAIPUR', 'Screenshot_2018-08-17-16-49-24-1.png'),
(95, 'SHYAM LAL JAIN', 'SHYAM LAL JAIN', 'NEEMOD', 9413885742, '1964-07-27', 'sljainnimod@gmail.com', '', 'SECTOR 9, 17/5 ALAKHNANDA APARTMENT. PRATAP NAGAR, JAIPUR (RAJASTHAN)', 'PHOTO.jpg'),
(96, 'VIKAS KUMAR JAIN', 'VIKAS KUMAR JAIN', 'NEEMOD', 9785410152, '1990-09-25', 'jain.vikash34@gmail.om', '', 'SECTOR 9, 17/5 ALAKHNANDA APARTMENT, PRATAP NAGAR, JAIPUR', '03 (2).jpg'),
(101, 'Ashok kumar jain', 'Ashok kumar jain ', 'Gudhachandrji', 9166833738, '1983-01-08', 'sherupoornima@gmail.com', '', '<br>', 'FB_IMG_1564916304011.jpg'),
(102, 'PARAS CHAND JAIN', 'TEACHER', 'KARAULI', 9461336836, '0000-00-00', 'ajeetjainmanan@gmail.com', '', '<br>', '20190815_164222.jpg'),
(103, 'AJEET KUMAR JAIN', '', 'GARHKHERA', 9461336836, '0000-00-00', 'ajeetjainmanan@gmail.com', '', '<br>', 'Screenshot_20190815-164143_PicsArt.jpg'),
(104, 'Mangal chand jain', 'JAIN STONE INDUSTRIES,RIICO INDUSTRIAL AREA KARAULI', 'Gangapur city', 9414407395, '1973-12-04', 'mangaljain088@gmail.com', '', 'C71, dayal nagar ,mirzapur, gangapur city, sawai madhopur, Rajasthan 322201', '20190807_163342.jpg'),
(107, 'Sumat Prakash Jain', 'Superintendent, Customs & CGST', 'Lalsot', 9414267852, '1964-01-11', 'sumatjainjain@yahoo.co.in', '', '<br>', 'ED2A14C8-FCB2-41BE-8456-1CA774EE55F0.jpeg'),
(111, 'Neelam Jain', 'Chandra prakash jain', 'Dabar', 9782890442, '1981-02-26', 'Jainneelam00@gmai.com', '', '<br>', 'IMG-20180226-WA0025.jpg'),
(112, 'Hanuman prasad jain', 'Building material ', 'Bhadoti', 9414486911, '1963-02-20', 'love.jain20aug@gmail.com', '', 'Arihant traders main road bhadoti ,teh-malarna dungar,sawai madhopur', 'IMG20190816135428.jpg'),
(113, 'Sunil Kumar Jain', 'Business gemstone', 'Sawai madhopur', 9829131540, '1967-11-02', 'sjsunil21167@gmail.com', '', '315 shanti Nagar road no. 2 opposite durgapura railway station Jaipur', 'IMG-20190816-WA0212.jpg'),
(114, 'Mukesh Jain', 'Service', 'Bamanwas', 9350004444, '0000-00-00', 'mukeshjain1068@gmail.com', '', 'H.No.1068C<div>Near Sadhana Park</div><div>Sector 10A</div><div>GURGAON 122001&nbsp; &nbsp;HR</div><div><br></div><div><br></div><div><br></div>', 'IMG-20190817-WA0149.jpg'),
(115, 'D.K. Jain', 'Service', 'Govindpura', 9811996874, '1970-01-01', 'dkjain1970@yahoo.com', '', 'Indirapuram, Ghaziabad, UP, 201014', 'thumbnail.jpg'),
(132, 'Rajendra prasad jain', 'Rajendra Prasad jain', 'Gurgaon', 9717293301, '1958-10-01', 'rpjain58@gmail.com', 'jain105716r', 'Gurgaon', 'IMG-20190815-WA0006.jpg'),
(148, 'mitthu lal saini', 'developer', 'tonk', 9269343151, '1994-01-01', 'gudiyasainisaini@gmail.com', '12345', 'Ramdwara Colony Purani Tonk Rajasthan', 'WhatsApp Image 2019-05-28 at 4.57.14 PM.jpeg'),
(149, 'Dr. Sumat Prakash Jain', 'Government servant', 'Liwali', 9460380289, '1968-06-27', 'sumatj1968@gmail.com', '1968', '52/140, v.t.road, mansarovar, jaipur, rajasthan', 'photo_2.jpg'),
(150, 'Mahesh Chand jain', 'Supplier', 'All Rajasthan', 9828116244, '1952-07-01', 'arihanttraders95@gmail.com', 'arihant223', '184/95pratap nager saganer jaipur', 'FB_IMG_1533398135515.jpg'),
(151, 'SUSHIL KUMAR JAIN', 'RAILWAY SERVICE', 'BHAWAR', 9461354172, '1970-07-22', 'skjain24901@gmail.com', 'jains2630426', '175/288, GOVIND NAGAR EAST AMER ROAD, JAIPUR<div>302002</div>', 'n.jpg'),
(152, 'Veeresh Kumar  jain ', 'Govt service', 'BHARATPUR ', 9461918917, '1961-02-22', 'veereshbpr@gmail.com', 'veeresh22', 'Near&nbsp; jain&nbsp; mandir&nbsp; &nbsp;mohalla&nbsp; gopal garh&nbsp; BHARATPUR&nbsp; Rajasthan&nbsp;', 'IMG-20190222-WA0011.jpg'),
(153, 'PADAM JAIN ', 'GARIBO KI blood collection Ke Dia. ', 'Bahated', 9414769556, '1960-11-14', 'Pdjain1960@gmail.com', '12345678', '52/569--sect--5&nbsp; PRATAP NAGAR SANGANER jaipur', 'homepage.zip'),
(154, 'Padam Kumar Jain', 'Govt. Pensioner', 'Jhalrapatan', 9887782656, '1952-09-06', 'padamjpatan@gmail.com', 'PKJAIN@67890', 'Ram Ji ki Gali Bheru ki kuyia ke samney Jhalrapatan District Jhalawar Rajasthan pin 326023', '1567048368564537776327.jpg'),
(155, 'Manish Kumar Jain', 'Private service', 'Jhalrapatan', 9414571519, '1988-06-07', 'my.manishjain@hot.mail.com', 'PKJAIN@67890', 'C/o Padam Kumar Jain Ram Ji ki Gali Bheru ki kuyia ke samney Jhalrapatan District Jhalawar Rajasthan pin 326023', 'scanner_20190829_090355');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `email`, `password`) VALUES
(1, 'lokesh@gmail.com', '123456'),
(2, 'gudiyasainisaini@gmail.com', '12345'),
(3, 'gudiyasainisaini11@gmail.com', '12345'),
(4, 'gudiyasainisaini1111@gmail.com', '123456'),
(5, 'gudiyasaini1saini@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `member_of_family`
--

CREATE TABLE `member_of_family` (
  `mof_auto_id` int(11) NOT NULL,
  `mof_id` int(11) NOT NULL,
  `mof_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mof_rel` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mof_dob` date NOT NULL,
  `mof_qua` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mof_job` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mof_marital_status` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mof_phone_num` bigint(20) NOT NULL,
  `mof_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mof_img` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `member_of_family`
--

INSERT INTO `member_of_family` (`mof_auto_id`, `mof_id`, `mof_name`, `mof_rel`, `mof_dob`, `mof_qua`, `mof_job`, `mof_marital_status`, `mof_phone_num`, `mof_email`, `mof_img`) VALUES
(1, 44, 'Ayush ', 'Son', '1989-06-18', 'MBA', 'Business Owner', 'Yes', 7891931999, 'aj180689@gmail.com', ''),
(4, 47, 'Anita jain', 'wife', '0000-00-00', 'B.A', 'Homemaker', 'Married', 7597061920, 'rkjain20@gmail.com', ''),
(5, 47, 'Krati Jain', 'Daughter', '0000-00-00', 'MBA. Fashion Designer', 'Service', 'Un married', 9413341206, 'rkjain343@gmail.com', ''),
(6, 47, 'Vaishali Jain', 'Daughter', '0000-00-00', 'B. Tech 5th Sem', 'Student', 'Un-married', 9413341206, 'rkjain343@gmail.co', ''),
(7, 48, 'Smt Shimla Jain', 'Wife', '0000-00-00', '8th pass', 'House Wife', 'Yes', 9414200141, 'kcjain86@yahoo.com', ''),
(8, 48, 'Ankit Jain', 'Son', '0000-00-00', 'CA', 'Own Business', 'Yes', 9001441444, 'ankitkcjain@gmail.com', ''),
(9, 49, 'Smt.  Sheela Jain', 'wife', '0000-00-00', 'M. A. ', 'govt teacher', 'Yes', 9929641391, 'sheelaj0408@gmail.com ', ''),
(10, 49, 'Anurag Jain', '', '0000-00-00', 'B. Tech', '', 'No', 9079326519, 'anuragjain918@gmail.com ', ''),
(11, 49, 'Samyak Jain', 'son', '0000-00-00', 'V Tech.  5th sem', '', 'no', 8385046456, 'jainsamyak215@gmail.com', ''),
(12, 56, 'suchitra jain', 'wife', '0000-00-00', 'B.COM', 'HOUSE EIFE', 'YES', 9694444022, 'NO', ''),
(13, 56, 'PAYAL JAIN ', 'DAUGHTER  ', '1993-11-04', 'M.COM', 'K S MOTER JAIPUR', 'SINGLE', 7689850857, 'NO', ''),
(14, 56, 'PULKIT JAIN', 'SON', '1999-10-04', 'B.TEK', 'NO', 'SINGLE', 7073064198, 'NO', ''),
(15, 56, 'PUNEET JAIN', 'SON', '0000-00-00', 'C.A ', 'NO', 'SINGLE', 8952063942, 'NO', ''),
(16, 57, 'SUNITA JAIN', 'WIFE', '1975-09-13', 'B.A', '', 'MARRIED', 9461601578, 'sunita96jain@gmail.com', ''),
(17, 57, 'SARANSH JAIN', 'SON', '1998-11-17', 'B.TECH  2nd year', '', 'UNMARRIED', 7597071817, 'saransh17jain@gmail.com', ''),
(18, 58, 'MANISHA JAIN', 'WIFE', '0000-00-00', '12 TH', 'HOUSE EIFE', 'MARRIED', 7014329530, 'NO', ''),
(19, 58, 'MANSHI JAIN', 'DAUGHTER  ', '2001-06-13', '11 TH', 'STUDEND', 'SINGLE', 0, 'NO', ''),
(20, 58, 'ABHISHEK', 'SON', '2002-06-16', '11 TH', 'STUDENT', 'SINGLE', 0, 'NO', ''),
(25, 64, 'HEMANT KUMAR JAIN', 'SON', '1971-09-16', 'B.COM', 'Government', 'YES', 9414203445, 'jainkumar1609@gmail.com', '_20160403_143532.jpg'),
(26, 64, 'ALKA JAIN', 'DAUGHTER IN LAW', '1977-07-02', 'HIGHER SECONDARY', 'HOUSE WIFE', 'YES', 9680300975, 'jainkumar1609@gmail.com', 'DSC04016.JPG'),
(27, 64, 'NIKHIL JAIN', 'GRAND SON', '1997-12-27', 'B.TECH SECOND YEAR', 'STUDENT', 'NO', 9530383596, 'nikhil5000jain@gmail.com', 'jmkm.jpg'),
(28, 64, 'NEHA JAIN', 'GRAND DAUGHTER', '2003-11-24', '9', 'STUDENT', 'NO', 9680300975, 'nehajain2432@gmail.com', 'IMG_20170408_155041.jpg'),
(29, 65, 'ALPANA JAIN', 'Wife', '1984-05-05', 'Graduation', 'LIC Agent', 'Yes', 8562830582, 'jainjk83@yahoo.in', '20190825_122702.jpg'),
(30, 68, 'Ashok jain', 'Son', '1964-01-30', 'ITI IN ELECTRONIC', 'SELF', 'YES', 9314323666, 'jainmobilenmore@gmail.com', 'IMG20170405092541.jpg'),
(31, 70, 'Leena Jain', 'Wife', '1989-06-02', 'MCA', 'House Wife', 'Yes', 7891431999, 'leenajain1989@gmail.com', 'logojain.png'),
(32, 71, 'Leena Jain', 'Wife', '1989-06-02', 'MCA', 'House Wife', 'Yes', 7891931999, 'aj180689@gmail.com', 'logojain.png'),
(33, 71, 'Arpita Jain', 'Sister', '1990-09-15', 'M.Com, Ca Inter', 'Private Job', 'No', 123456789, 'xyz@gmail.com', 'logojain.png'),
(34, 72, 'Shishanshu Jain ', 'Sun', '1996-07-27', 'BE', 'Student ', 'No', 8519007476, 'Jshishanshu@gmail.com', 'B612_20170928_091255.jpg'),
(35, 78, 'Arun jqin', 'Father', '1980-12-10', 'MBA', 'ATC Mobile Tower Company', 'Married', 9950053334, 'Arunjap@gmail.com', 'IMG_20170908_204427.jpg'),
(36, 79, 'Geeta Jain', 'Wife', '1966-02-03', '5th', 'House Wife', 'Yes', 9784725101, 'virendrajain10@gmail.com', 'MOM.jpg'),
(37, 80, 'Geeta Jain', 'Wife', '1966-02-03', '5th', 'House Wife', 'Yes', 9784725101, 'virendrajain10@gmail.com', 'MOM.jpg'),
(38, 81, 'Geeta Jain', 'Wife', '1966-02-03', '5th', 'House Wife', 'Yes', 9784725101, 'virendrajain10@gmail.com', 'MOM.jpg'),
(39, 81, 'Gokulendra Jain', 'Son', '1984-03-02', 'MA/B.ED', 'Business - Noble Institute ', 'Yes', 9828449834, 'gokulendrakumarjain@gmail.com', 'Gokulendra.jpg'),
(40, 81, 'Pooja Jain', 'Daughter in Law', '1987-10-30', 'MA/ B.ED', 'House Wife', 'Yes', 8769205939, 'gokulendrakumarjain@gmail.com', 'Pooja.jpg'),
(41, 81, 'Virendra Jain', 'Son', '1986-06-07', 'MBA', 'FS Realty (Realestate)  - Sr. Manager -Sales & Marketing', 'Yes', 9530004800, 'virendrajain10@gmail.com', 'Virendra.JPG'),
(42, 81, 'Indu Bala Jain', 'Daughter In Law', '1986-10-10', 'MA', 'House wife', 'Yes', 9950464807, 'virendrajain10@gmail.com', 'Indu Bala.jpg'),
(43, 89, 'Kiran Jain', 'Wife', '1964-10-24', '10', 'House Wife', 'Yes', 9303551114, 'Suniljain2121@yahoo.com ', 'IMG_20171209_142645.jpg'),
(44, 91, 'INDRA JAIN', 'WIFE', '1970-12-01', 'M.A., B.ED.', 'GOVERNMENT SERVICE - TEACHER', 'YES', 9414362665, 'satishjain64@gmail.com', 'Indra.jpg'),
(45, 91, 'ADITYA JAIN', 'SON', '1991-06-24', 'B-TECH', 'SE Analyst (SAP Consultant), Accenture, Pune', 'NO', 7030348008, 'aditya.f.jain@accenture.com', 'IMG-20170704-WA0023 (5).jpg'),
(46, 91, 'AKSHAY JAIN', 'SON', '1993-08-16', 'B-Tech (IC) Nirma University ', ' Preparing for indian Civil Services ', 'No', 7405916004, 'satishjain64@gmail.com', 'Akshay.jpg'),
(47, 92, 'Shilpa Jain', 'Wife ', '1987-02-23', 'M. A., B. Ed. ', 'NA', 'Yes', 9413023896, 'Bpjains@gmail.com ', 'IMG_20180710_193132.jpg'),
(48, 92, 'Kripal Jain', 'Daughter ', '2017-04-04', 'Minor ', 'Minor ', 'No', 9772834000, 'Bpjains@gmail.com ', 'IMG_20180811_151840.jpg'),
(49, 94, 'Pinky jain', 'Wife', '1972-07-06', 'M.A, B.Ed', 'Private service', 'Yes', 9887881069, 'Pinku1069@gmail.com', 'IMG-20180813-WA0061.jpg'),
(50, 95, 'VIKAS KUMAR JAIN', 'FATHER', '1993-02-15', 'M.COM + DIPLOMA', 'OFFICE ASSISTANT', 'YES', 9785410152, 'jain.vikash34@gmail.com', 'Photo (Large).jpg'),
(51, 100, 'Rama jain', 'Wifr', '1982-05-15', 'Double MA BEd', 'Govt teacher', 'Yes', 9166833771, 'sherupoornima@gmail.com', '20160501_193923.jpg'),
(54, 111, 'Richa jain', 'Wife ', '1988-04-22', 'B.A.', 'House wife', 'Yes', 9782643543, 'Jainneelam00@gmail.com', 'IMG-20190401-WA0185.jpg'),
(55, 111, 'Ishika jain', 'Daughter ', '2011-08-22', '3', '', 'No', 9057528603, 'Jainneelam00@gmail.com', 'IMG-20190401-WA0178.jpg'),
(56, 111, 'Gravity jain', 'Son', '2015-07-05', 'Kg', '', 'No', 7014765802, 'Jainneelam00@ Gmail.com', '1561704398791.jpg'),
(57, 112, 'Nonendra Kumar jain', 'Son', '0000-00-00', 'B.sc', 'Food corporation of india', 'Yes', 9887256856, 'nonendra.jain@gmail.com', 'IMG20190816140423.jpg'),
(58, 112, 'Ritika jain', 'Daughter in law', '0000-00-00', 'M.a', 'No', 'Yes', 9887256856, 'nonendra.jain@gmail.com', 'IMG20190816154633.jpg'),
(59, 112, 'Love jain', 'Son', '0000-00-00', 'M.com', 'No', 'No', 9461623142, 'love.jain20aug@gmail.com', 'IMG20190816135953.jpg'),
(83, 148, 'chavi11', 'doughter11', '2015-01-01', 'UKG11', 'no11', 'no11', 8503021882, 'chavi@gmail.com11', 'feedback2.png'),
(84, 148, 'lokesh', 'son', '2014-01-01', '5th', 'no', 'no', 7412589332, 'lokesh@gmail.com', 'feedback2.png'),
(85, 149, 'Renu Jain', 'wife', '1973-12-20', 'B.A. , N.T.T', 'teacher', 'yes', 9414869820, 'renujain52140@gmail.com', 'photo_1.jpg'),
(86, 149, 'Kanika Jain', 'Daughter', '1998-01-13', 'Bachelor of dental surgery (B.D.S.)', 'student', 'no', 8952854885, 'kanikajain52@yahoo.com', 'photo_5.jpg'),
(87, 149, 'Darshan Jain', 'son', '2000-08-01', 'B.Tech (cse)', 'student', 'no', 7611039678, 'jdarshan2000@gmail.com', 'photo_6.jpg'),
(88, 149, 'Ramji lal Jain', 'Father', '1931-07-01', 'M.A.,B.Ed', 'retiered teacher', 'yes', 9460831494, 'nill', 'photo_3.jpg'),
(89, 149, 'Bhagwanti Devi Jain', 'Mother', '1941-04-01', '5th pass', 'housewife', 'yes', 8104670035, 'nill', 'photo_4.jpg'),
(90, 150, 'Manish Kumar jain', 'Son', '1975-11-23', 'M.a.', 'Govt supplier and ss', 'Govts', 9828291706, 'arihanttraders95@gmail.com', 'IMG-20181110-WA0003.jpg'),
(91, 150, 'Sunita jain', 'Son wife', '1979-02-14', 'B.a.', 'Personal', 'Yes', 9166625340, 'arihanttraders95@gmail.com', 'IMG20190331174843.jpg'),
(92, 150, 'Arihant jain', 'Grand son', '2008-01-04', '10', 'Reading ', 'Y', 9166625340, 'arihanttraders95@gmail.com', 'IMG20190217221712.jpg'),
(93, 150, 'Naman jain', 'Grand son', '2008-05-05', '7', 'Reading', 'Y', 9166625340, 'arihanttraders95@gmail.com', 'IMG20190505201657.jpg'),
(94, 152, 'Vipul jIn', 'Son', '1993-05-05', 'B.Tech', 'Business ', 'No', 8302614310, 'Veereshbpr@gmail.com ', 'IMG-20180226-WA0001.jpg'),
(95, 154, 'SMT. Shanta Jain', 'Wife', '1961-06-29', 'Middle', 'Home wife', 'Yes', 9887782656, 'padamjpatan@gmail.com', '1567048608241944796569.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `id` int(20) NOT NULL,
  `name` varchar(120) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `ram` char(5) NOT NULL,
  `storage` varchar(50) NOT NULL,
  `camera` varchar(20) NOT NULL,
  `image` varchar(100) NOT NULL,
  `quantity` mediumint(5) NOT NULL,
  `status` enum('0','1') NOT NULL COMMENT '0-active,1-inactive'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_details`
--

INSERT INTO `product_details` (`id`, `name`, `brand`, `price`, `ram`, `storage`, `camera`, `image`, `quantity`, `status`) VALUES
(1, 'Honor 9 Lite (Sapphire Black, 64 GB) (4 GB RAM)', 'Honor', 14499.00, '4', '64', '13', '1.png', 10, '1'),
(2, 'Infinix (Sandstone Blue, 32 GB) (3 GB RAM)', 'Infinix', 8999.00, '3', '32', '13', '2.png', 10, '1'),
(3, 'VIVO V8 Youth (Black, 32 GB) (4 GB RAM)', 'VIVO', 16990.00, '4', '32', '16', '3.png', 10, '1'),
(4, 'Moto (Gold, 32 GB) (3 GB RAM)', 'Moto', 11499.00, '3', '32', '8', '4.png', 10, '1'),
(5, 'Lenovo (Venom Black, 32 GB) (3 GB RAM)', 'Lenevo', 8999.00, '3', '32', '13', '5.png', 10, '1'),
(6, 'Samsung Galaxy (Gold, 16 GB) (3 GB RAM)', 'Samsung', 11990.00, '3', '16', '13', '6.png', 10, '1'),
(7, 'Moto Plus (Pearl White, 16 GB) (2 GB RAM)', 'Moto', 8799.00, '2', '16', '8', '7.png', 10, '1'),
(8, 'Panasonic (White, 16 GB) (1 GB RAM)', 'Panasonic', 6999.00, '1', '16', '8', '8.png', 10, '1'),
(9, 'OPPO (Black, 64 GB) (6 GB RAM)', 'OPPO', 18990.00, '6', '64', '16', '9.png', 10, '1'),
(10, 'Honor 7 (Gold, 32 GB) (3 GB RAM)', 'Honor', 9999.00, '3', '32', '13', '10.png', 10, '1'),
(11, 'Asus ZenFone (Midnight Blue, 64 GB) (6 GB RAM)', 'Asus', 27999.00, '6', '128', '12', '11.png', 10, '1'),
(12, 'Redmi 5A (Gold, 32 GB) (3 GB RAM)', 'MI', 5999.00, '3', '32', '13', '12.png', 10, '1'),
(13, 'Intex (Black, 16 GB) (2 GB RAM)', 'Intex', 5999.00, '2', '16', '8', '13.png', 10, '1'),
(14, 'Google Pixel (18:9 Display, 64 GB) White', 'Google', 62990.00, '4', '64', '12', '14.png', 10, '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bm_admin_users`
--
ALTER TABLE `bm_admin_users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `head_of_family`
--
ALTER TABLE `head_of_family`
  ADD PRIMARY KEY (`hof_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member_of_family`
--
ALTER TABLE `member_of_family`
  ADD PRIMARY KEY (`mof_auto_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bm_admin_users`
--
ALTER TABLE `bm_admin_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `head_of_family`
--
ALTER TABLE `head_of_family`
  MODIFY `hof_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `member_of_family`
--
ALTER TABLE `member_of_family`
  MODIFY `mof_auto_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
