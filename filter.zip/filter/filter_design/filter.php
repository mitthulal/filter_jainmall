<html>
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Live Data Search using Multiple Tag in PHP with Ajax</title>  

  <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>

  <?php 
	include 'head.php';
	include 'db_connector.php';	
?>
<div class="page-wrap">

    <?php include 'header.php';?>
	<div class="container">
		<div class="row">
			<h3 class="header-text">Details</h3>
			  <div class="form-group">
   
   </div>
  
  <style>
  .bootstrap-tagsinput {
   width: 100%;
  }
  </style>
 </head>
 <body>
  <div class="container">
 
   
   <div class="form-group">
    <!--<div class="row">-->
    <!-- <div class="col-md-10">-->
    <!--  <input type="text" id="tags" class="form-control" data-role="tagsinput" />-->
    <!-- </div>-->
    <!-- <div class="col-md-2">-->
    <!--  <button type="button" name="search" class="btn btn-primary" id="search">Search</button>-->
    <!-- </div>-->
    <!--</div>-->
    <div class='col-xs-12 col-sm-12 col-md-2 col-lg-2'></div>
      <div class='col-xs-12 col-sm-12 col-md-8 col-lg-8'>

        <form class='navbar-form'>
          <div class='input-group'>
            <input class='form-control' type="text" id="tags" class="form-control" data-role="tagsinput" />
            <span class="input-group-btn">
              <button type='button' name="search" class="btn btn-primary" id="search" style="padding: 15px;">
                <span class='glyphicon glyphicon-search'></span>
              </button>
            </span>

          </div>
        </form>

      </div>
        <div class='col-xs-12 col-sm-12 col-md-2 col-lg-2'></div>
   </div>
   <br />
   <div class="">
    <div align="right">
     <p><b>Total Records - <span id="total_records"></span></b></p>
    </div>
    <table class="">
     <!--<thead>-->
     <!-- <tr>-->
     <!--  <th>Customer Name</th>-->
     <!--  <th>Gender</th>-->
     <!--  <th>Address</th>-->
     <!--  <th>City</th>-->
     <!--  <th>Postal Code</th>-->
     <!--  <th>Country</th>-->
     <!-- </tr>-->
     <!--</thead>-->
     <tbody>
     </tbody>
    </table>
   </div>
  </div>
  <div style="clear:both"></div>
   </div>
   </div>
   </div>
 
 </body>
</html>
	<div class="modal fade popup-form" id="detail" style="padding: 103px 34px 12px;">
          <div class="modal-dialog">
            <div class="modal-content">
        
              <!-- Modal Header -->
              <div class="modal-header">
                <h4 class="modal-title">Please Enter Email Password!</h4>
                <i class="fa fa-envelope-open" aria-hidden="true"></i>
                <button type="button" class="close" data-dismiss="modal"><i class="fa fa-window-close" aria-hidden="true"></i></button>
              </div>
        
              <!-- Modal body -->
              <div class="modal-body">
            <form method="POST" action="edit.php">
      
            
            <div class="form-group">
              <input type="email" class="form-control" id="email" name="email" placeholder="*Email" >
            </div>
             <div class="form-group">
              <input type="password" class="form-control" id="password" name="password" placeholder="*Password" >
            </div>
            
            <button type="submit" id="submit" name="submit"  class="btn btn-block text-uppercase btn-book submit-now">SUBMIT</button>
			</form>
              </div>
        
              <!-- Modal footer -->
              <div class="modal-footer">
                <button style="    float: left;border: 0px;padding: 0px;">  <a href="forget.php">Forget Password</a></button>
                <button type="submit" class="btn btn-success" data-dismiss="modal">Close</button>
              </div>
        
            </div>
          </div>
        </div>
<style>
    .cont{
    /*width: 30.36%;*/
    padding: 5px 5px 5px 5px;
    }
    .directory-detail img {
    border: 3px solid #ff632d;
    }
    .img-responsive, .thumbnail > img, .thumbnail a > img, .carousel-inner > .item > img, .carousel-inner > .item > a > img {
    display: block;
    /*height: 313px;*/
    /*width: 100%;*/
}
.detail{
    /*width: 37.36%;*/
    /*padding-top: 20px;*/
    color: #;
    color: #000;
    font-size: 20px;
    font-weight: bold;
}
.h41{
    /*width: 37.36%;*/
    /*padding-top: 20px;*/
    color: #;
    color: #f94d09;
    font-size: 20px;
    font-weight: bold;
    margin-bottom:0px;
}
</style>
<script>
$(document).ready(function(){
 
 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{query:query},
   dataType:"json",
   success:function(data)
   {
    $('#total_records').text(data.length);
    var html = '';
    if(data.length > 0)
    {
     for(var count = 0; count < data.length; count++)
     {
         
      html += '<div class="container" style="padding-left:0px;padding-right:0px;">';
      html += '<div class="row" style="margin-bottom:20px;border:1px solid;">';
      html += '<div class="col-md-4 cont">';
    
      html += '<img style="height:313px;width:100%;" class="img-responsive" src="http://shrimaaljainsamaj.com/images/family/'+data[count].hof_img+'">';
      html += '</div>';
       html += '<div class="col-md-4" style="width:37.36%">';
        html += '<h4 class="h41">name</h4>';
        
      html += '<p class="detail">'+data[count].hof_name+'</p>';
      html += '<h4 class="h41">Native Place</h4>';
      html += '<p class="detail">'+data[count].hof_native_place+'</p>';
       html += '<h4 class="h41">Contact</h4>';
      html += '<p class="detail">'+data[count].hof_mob_num+'</p>';
       html += '<h4 class="h41">Email</h4>';
      html += '<p class="detail">'+data[count].hof_email+'</p>';
      html += '<a href="javascript:void(0)" data-target="#detail" data-toggle="modal" style="margin-top:35px;float:left" class="btn btn-primary">Edit Your Profile</a>';
      html += '</div>';
       html += '<div class="col-md-4" style="width:28.36%">';
        html += '<h4 class="h41">D.O.B</h4>';
      html += '<p class="detail">'+data[count].hof_dob+'</p>';
       html += '<h4 class="h41">Job Title</h4>';
      html += '<p class="detail">'+data[count].hof_job+'</p>';
       html += '<h4 class="h41">Address</h4>';
      html += '<p class="detail">'+data[count].hof_add+'</p>';
       html += '<a href="view-all-details.php?id='+data[count].hof_id+'" style="margin-top:35px;float:left" class="btn btn-primary">View All Details</a>';
      html += '</div>';
      html += '</div>';
      html += '</div>';
     }
    }
    else
    {
     html = '<tr><td colspan="5">No Data Found</td></tr>';
    }
    $('tbody').html(html);
   }
  })
 }

 $('#search').click(function(){
  var query = $('#tags').val();
  load_data(query);
 });

});
</script>
<?php include'footer.php'; ?>
<script src="js/jquery-1.11.0.min.js"></script> 
<script src="../../../ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/dscountdown.min.js"></script> 
<script src="js/jquery.appear.js"></script> 
<script src="js/jquery.prettyPhoto.js"></script> 
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script> 

<!-- revolution slider --> 

<script src="js/jquery.themepunch.revolution.min.js"></script> 
	<script src="js/script.js"></script> 
	<script src="js/jquery.bxslider.min.js"></script> 
	<script src="js/custom.js"></script> 
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script> 
	
	
	<script type="text/javascript">
		$(document).ready(function(){
			
		})
	</script>
