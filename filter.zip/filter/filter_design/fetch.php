
<?php

//fetch.php

$connect = new PDO("mysql:host=localhost;dbname=shrimaal_jain", "shrimaal_jain", "jain@2017");

$output = '';

$query = '';

if(isset($_POST["query"]))
{
 $search = str_replace(",", "|", $_POST["query"]);
 $query = "
 SELECT * FROM head_of_family 
 WHERE hof_name REGEXP '".$search."'
 OR hof_id REGEXP '".$search."'
 OR hof_dob REGEXP '".$search."' 
  OR hof_native_place REGEXP '".$search."' 
   OR hof_mob_num REGEXP '".$search."' 
   OR hof_dob REGEXP '".$search."'
   OR hof_Job REGEXP '".$search."'
    OR hof_email REGEXP '".$search."'
   OR hof_add REGEXP '".$search."'
 OR hof_img REGEXP '".$search."' 

 ";
}
else
{
 $query = "
 SELECT * FROM head_of_family ORDER BY hof_id
 ";
}

$statement = $connect->prepare($query);
$statement->execute();

while($row = $statement->fetch(PDO::FETCH_ASSOC))
{
 $data[] = $row;
}

echo json_encode($data);

?>
