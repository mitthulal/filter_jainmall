<?php 
session_start();
include('inc/header.php');
?>
<title>phpzag.com : Demo Product Search Filter with Ajax, PHP & MySQL</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/9.8.0/css/bootstrap-slider.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/9.8.0/bootstrap-slider.min.js"></script>
<script src="js/search.js"></script>
<link rel="stylesheet" href="css/style.css">
<?php include('inc/container.php');?>
<div class="container">		
	<h2>Example: Product Search Filter with Ajax, PHP & MySQL</h2>
	<?php
	include 'class/Product.php';
	$product = new Product();	
	?>	
	<div class="row">
	<div class="col-md-3">                    
	
		
		<div class="list-group">
			<h3>Internal Storage</h3>
			<?php
			$brand = $product->getStorage();
			foreach($brand as $storageDetails){	
			?>
			<div class="list-group-item checkbox">
			<label><input type="text" class="productDetail storage" value="<?php echo $storageDetails['brand']; ?>"  ></label>
			</div>
			<?php
			}
			?> 
		</div>
	</div>
	<div class="col-md-9">
	 <br />
		<div class="row searchResult">
		</div>
	</div>
    </div>	
</div>	
<?php include('inc/footer.php');?>






